import React from 'react';
import { 
  MapPin, 
  Bed, 
  Bath, 
  Car, 
  Square, 
  Eye, 
  Edit, 
  Trash2,
  Star,
  Wifi,
  AirVent
} from 'lucide-react';
import { Property } from '../../types';

interface PropertyCardProps {
  property: Property;
  onView: (id: string) => void;
  onEdit: (id: string) => void;
  onDelete: (id: string) => void;
}

const PropertyCard: React.FC<PropertyCardProps> = ({ 
  property, 
  onView, 
  onEdit, 
  onDelete 
}) => {
  const statusColors = {
    available: 'bg-green-100 text-green-800',
    rented: 'bg-blue-100 text-blue-800',
    maintenance: 'bg-yellow-100 text-yellow-800',
    sold: 'bg-gray-100 text-gray-800'
  };

  const statusLabels = {
    available: 'متاح',
    rented: 'مؤجر',
    maintenance: 'صيانة',
    sold: 'مباع'
  };

  const typeLabels = {
    apartment: 'شقة',
    house: 'فيلا',
    commercial: 'تجاري',
    land: 'أرض'
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden hover:shadow-lg transition-all duration-300 group">
      <div className="relative">
        <img 
          src={property.images[0] || 'https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg?auto=compress&cs=tinysrgb&w=400'}
          alt={property.title}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 right-4">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${statusColors[property.status]}`}>
            {statusLabels[property.status]}
          </span>
        </div>
        <div className="absolute top-4 left-4">
          <span className="bg-slate-800 text-white px-3 py-1 rounded-full text-xs font-medium">
            {typeLabels[property.type]}
          </span>
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-lg font-semibold text-slate-900 text-right flex-1">
            {property.title}
          </h3>
          <div className="flex items-center space-x-1 space-x-reverse text-amber-500">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-current" />
            ))}
          </div>
        </div>

        <div className="flex items-center text-slate-600 mb-4 text-right">
          <MapPin className="w-4 h-4 ml-1" />
          <span className="text-sm">{property.address}</span>
        </div>

        <div className="grid grid-cols-4 gap-4 mb-4">
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Square className="w-4 h-4 text-slate-500" />
            </div>
            <span className="text-xs text-slate-600">{property.area}م²</span>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Bed className="w-4 h-4 text-slate-500" />
            </div>
            <span className="text-xs text-slate-600">{property.rooms}</span>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Bath className="w-4 h-4 text-slate-500" />
            </div>
            <span className="text-xs text-slate-600">{property.bathrooms}</span>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Car className={`w-4 h-4 ${property.parking ? 'text-green-500' : 'text-slate-300'}`} />
            </div>
            <span className="text-xs text-slate-600">{property.parking ? 'متوفر' : 'غير متوفر'}</span>
          </div>
        </div>

        {property.amenities && property.amenities.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {property.amenities.slice(0, 3).map((amenity, index) => (
              <span key={index} className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-slate-100 text-slate-700">
                {amenity === 'wifi' && <Wifi className="w-3 h-3 mr-1" />}
                {amenity === 'ac' && <AirVent className="w-3 h-3 mr-1" />}
                {amenity}
              </span>
            ))}
            {property.amenities.length > 3 && (
              <span className="text-xs text-slate-500">+{property.amenities.length - 3} المزيد</span>
            )}
          </div>
        )}

        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <div className="text-right">
            <p className="text-2xl font-bold text-slate-900">
              {property.price.toLocaleString()} <span className="text-lg text-slate-600">ر.س</span>
            </p>
            <p className="text-sm text-slate-500">شهرياً</p>
          </div>
          
          <div className="flex items-center space-x-2 space-x-reverse">
            <button
              onClick={() => onView(property.id)}
              className="p-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
            >
              <Eye className="w-5 h-5" />
            </button>
            <button
              onClick={() => onEdit(property.id)}
              className="p-2 text-slate-600 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-all"
            >
              <Edit className="w-5 h-5" />
            </button>
            <button
              onClick={() => onDelete(property.id)}
              className="p-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;