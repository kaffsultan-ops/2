import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  Home, 
  Building, 
  Users, 
  UserCheck, 
  FileText, 
  Wrench, 
  CreditCard, 
  Bell, 
  BarChart3,
  Settings,
  X
} from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const navItems = [
    { to: '/', icon: Home, label: 'لوحة التحكم' },
    { to: '/properties', icon: Building, label: 'العقارات' },
    { to: '/owners', icon: Users, label: 'الملاك' },
    { to: '/tenants', icon: UserCheck, label: 'المستأجرين' },
    { to: '/contracts', icon: FileText, label: 'العقود' },
    { to: '/maintenance', icon: Wrench, label: 'الصيانة' },
    { to: '/payments', icon: CreditCard, label: 'المدفوعات' },
    { to: '/notifications', icon: Bell, label: 'الإشعارات' },
    { to: '/reports', icon: BarChart3, label: 'التقارير' },
    { to: '/settings', icon: Settings, label: 'الإعدادات' },
  ];

  return (
    <>
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden" 
          onClick={onClose}
        />
      )}
      
      <aside className={`
        fixed top-0 right-0 h-full w-72 bg-gradient-to-b from-slate-900 to-slate-800 
        border-l border-slate-700 z-50 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : 'translate-x-full'}
        lg:translate-x-0 lg:static lg:z-auto
      `}>
        <div className="flex items-center justify-between p-6 border-b border-slate-700">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-600 rounded-lg flex items-center justify-center">
              <Building className="w-6 h-6 text-white" />
            </div>
            <div className="text-right">
              <h1 className="text-xl font-bold text-white">إدارة العقارات</h1>
              <p className="text-sm text-slate-300">نظام متكامل</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="lg:hidden text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <nav className="p-4 space-y-2">
          {navItems.map(({ to, icon: Icon, label }) => (
            <NavLink
              key={to}
              to={to}
              onClick={onClose}
              className={({ isActive }) => `
                flex items-center space-x-3 space-x-reverse p-3 rounded-lg transition-all duration-200
                ${isActive 
                  ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-lg' 
                  : 'text-slate-300 hover:bg-slate-700 hover:text-white'
                }
              `}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-slate-800 rounded-lg p-4 border border-slate-600">
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold">م</span>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-white">مدير النظام</p>
                <p className="text-xs text-slate-400">admin@company.com</p>
              </div>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;