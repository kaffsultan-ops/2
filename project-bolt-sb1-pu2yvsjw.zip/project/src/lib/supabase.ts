import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co';
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder-key';

// Only create client if we have valid environment variables
export const supabase = import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY 
  ? createClient(supabaseUrl, supabaseKey)
  : null;

// Helper function to check if Supabase is configured
export const isSupabaseConfigured = () => {
  return !!(import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY);
};
// Database operations
export const propertyService = {
  // Properties
  async getProperties() {
    if (!supabase) throw new Error('Supabase not configured');
    const { data, error } = await supabase
      .from('properties')
      .select(`
        *,
        owner:owners(*),
        tenant:tenants(*),
        maintenance:maintenance_requests(*)
      `);
    if (error) throw error;
    return data;
  },

  async createProperty(property: Omit<Property, 'id' | 'created_at' | 'updated_at'>) {
    if (!supabase) throw new Error('Supabase not configured');
    const { data, error } = await supabase
      .from('properties')
      .insert(property)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  // Owners
  async getOwners() {
    if (!supabase) throw new Error('Supabase not configured');
    const { data, error } = await supabase
      .from('owners')
      .select('*');
    if (error) throw error;
    return data;
  },

  async createOwner(owner: Omit<Owner, 'id' | 'created_at' | 'updated_at' | 'properties_count'>) {
    if (!supabase) throw new Error('Supabase not configured');
    const { data, error } = await supabase
      .from('owners')
      .insert(owner)
      .select()
      .single();
    if (error) throw error;
    return data;
  },

  // Tenants
  async getTenants() {
    if (!supabase) throw new Error('Supabase not configured');
    const { data, error } = await supabase
      .from('tenants')
      .select(`
        *,
        property:properties(*)
      `);
    if (error) throw error;
    return data;
  },

  // Maintenance
  async getMaintenance() {
    if (!supabase) throw new Error('Supabase not configured');
    const { data, error } = await supabase
      .from('maintenance_requests')
      .select(`
        *,
        property:properties(title, address)
      `);
    if (error) throw error;
    return data;
  },

  // Payments
  async getPayments() {
    if (!supabase) throw new Error('Supabase not configured');
    const { data, error } = await supabase
      .from('payments')
      .select(`
        *,
        tenant:tenants(name),
        property:properties(title, address)
      `);
    if (error) throw error;
    return data;
  },

  // Dashboard stats
  async getDashboardStats(): Promise<DashboardStats> {
    if (!supabase) throw new Error('Supabase not configured');
    const [properties, payments, maintenance] = await Promise.all([
      supabase.from('properties').select('status'),
      supabase.from('payments').select('status, amount'),
      supabase.from('maintenance_requests').select('status')
    ]);

    const totalProperties = properties.data?.length || 0;
    const occupiedProperties = properties.data?.filter(p => p.status === 'rented').length || 0;
    const totalRevenue = payments.data?.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0) || 0;
    const pendingPayments = payments.data?.filter(p => p.status === 'pending').length || 0;
    const maintenanceRequests = maintenance.data?.filter(m => m.status === 'pending').length || 0;

    return {
      total_properties: totalProperties,
      occupied_properties: occupiedProperties,
      total_revenue: totalRevenue,
      pending_payments: pendingPayments,
      maintenance_requests: maintenanceRequests,
      expiring_contracts: 0
    };
  }
};