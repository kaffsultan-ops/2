import React, { useState, useEffect } from 'react';
import { 
  Building, 
  Users, 
  TrendingUp, 
  AlertCircle, 
  Wrench, 
  Calendar,
  DollarSign,
  UserCheck
} from 'lucide-react';
import StatsCard from '../components/Dashboard/StatsCard';
import RevenueChart from '../components/Dashboard/RevenueChart';
import { DashboardStats } from '../types';
import { propertyService, isSupabaseConfigured } from '../lib/supabase';

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats>({
    total_properties: 0,
    occupied_properties: 0,
    total_revenue: 0,
    pending_payments: 0,
    maintenance_requests: 0,
    expiring_contracts: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardStats();
  }, []);

  const loadDashboardStats = async () => {
    try {
      if (isSupabaseConfigured()) {
        const dashboardStats = await propertyService.getDashboardStats();
        setStats(dashboardStats);
      } else {
        // Use mock data when Supabase is not configured
        setStats({
          total_properties: 24,
          occupied_properties: 18,
          total_revenue: 156000,
          pending_payments: 3,
          maintenance_requests: 5,
          expiring_contracts: 2
        });
      }
    } catch (error) {
      console.error('Error loading dashboard stats:', error);
      // Fallback to mock data on error
      setStats({
        total_properties: 0,
        occupied_properties: 0,
        total_revenue: 0,
        pending_payments: 0,
        maintenance_requests: 0,
        expiring_contracts: 0
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-amber-500"></div>
      </div>
    );
  }

  const occupancyRate = stats.total_properties > 0 
    ? Math.round((stats.occupied_properties / stats.total_properties) * 100) 
    : 0;

  const recentActivities = [
    { id: 1, type: 'payment', message: 'تم استلام دفعة إيجار من أحمد محمد', time: 'منذ ساعة', color: 'green' },
    { id: 2, type: 'maintenance', message: 'طلب صيانة جديد لشقة في الرياض', time: 'منذ 3 ساعات', color: 'yellow' },
    { id: 3, type: 'contract', message: 'تم تجديد عقد إيجار شقة في جدة', time: 'أمس', color: 'blue' },
    { id: 4, type: 'tenant', message: 'مستأجر جديد انضم لفيلا في الدمام', time: 'يوم أمس', color: 'purple' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-slate-900 text-right">لوحة التحكم</h1>
        <div className="text-right">
          <p className="text-lg text-slate-600">أهلاً بك مرة أخرى</p>
          <p className="text-sm text-slate-500">آخر تحديث: الآن</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="إجمالي العقارات"
          value={stats.total_properties}
          change={`معدل الإشغال ${occupancyRate}%`}
          icon={Building}
          color="blue"
          trend="up"
        />
        <StatsCard
          title="العقارات المؤجرة"
          value={stats.occupied_properties}
          change={`من أصل ${stats.total_properties} عقار`}
          icon={UserCheck}
          color="green"
          trend="up"
        />
        <StatsCard
          title="إجمالي الإيرادات"
          value={`${stats.total_revenue.toLocaleString()} ر.س`}
          change="زيادة 12% عن الشهر الماضي"
          icon={DollarSign}
          color="amber"
          trend="up"
        />
        <StatsCard
          title="المدفوعات المعلقة"
          value={stats.pending_payments}
          change="تحتاج متابعة"
          icon={AlertCircle}
          color="red"
          trend="down"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="lg:col-span-2">
          <RevenueChart />
        </div>

        {/* Quick Stats */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 text-right">إحصائيات سريعة</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <span className="text-2xl font-bold text-green-600">{occupancyRate}%</span>
                <div className="text-right">
                  <p className="text-sm font-medium text-slate-900">معدل الإشغال</p>
                  <p className="text-xs text-slate-500">من إجمالي العقارات</p>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <span className="text-2xl font-bold text-amber-600">{stats.maintenance_requests}</span>
                <div className="text-right">
                  <p className="text-sm font-medium text-slate-900">طلبات الصيانة</p>
                  <p className="text-xs text-slate-500">في انتظار المعالجة</p>
                </div>
              </div>
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <span className="text-2xl font-bold text-blue-600">{stats.expiring_contracts}</span>
                <div className="text-right">
                  <p className="text-sm font-medium text-slate-900">عقود منتهية الصلاحية</p>
                  <p className="text-xs text-slate-500">خلال 30 يوم</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
            <h3 className="text-lg font-semibold text-slate-900 mb-4 text-right">الأنشطة الأخيرة</h3>
            <div className="space-y-3">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3 space-x-reverse p-3 hover:bg-slate-50 rounded-lg transition-colors">
                  <div className={`w-2 h-2 rounded-full mt-2 ${
                    activity.color === 'green' ? 'bg-green-500' :
                    activity.color === 'yellow' ? 'bg-yellow-500' :
                    activity.color === 'blue' ? 'bg-blue-500' : 'bg-purple-500'
                  }`} />
                  <div className="flex-1 text-right">
                    <p className="text-sm text-slate-900">{activity.message}</p>
                    <p className="text-xs text-slate-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;