import React, { useState, useEffect } from 'react';
import { Plus, Filter, Grid, List } from 'lucide-react';
import PropertyCard from '../components/Properties/PropertyCard';
import { Property } from '../types';
import { propertyService } from '../lib/supabase';

const Properties: React.FC = () => {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');

  useEffect(() => {
    loadProperties();
  }, []);

  const loadProperties = async () => {
    try {
      const data = await propertyService.getProperties();
      setProperties(data || []);
    } catch (error) {
      console.error('Error loading properties:', error);
      // Add mock data for demo
      setProperties([
        {
          id: '1',
          title: 'شقة فاخرة في الرياض',
          address: 'حي العليا، الرياض',
          type: 'apartment',
          area: 120,
          rooms: 3,
          bathrooms: 2,
          parking: true,
          furnished: true,
          price: 4500,
          status: 'rented',
          owner_id: '1',
          images: ['https://images.pexels.com/photos/1643383/pexels-photo-1643383.jpeg?auto=compress&cs=tinysrgb&w=400'],
          amenities: ['wifi', 'ac', 'elevator'],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        },
        {
          id: '2',
          title: 'فيلا مستقلة في جدة',
          address: 'حي الروضة، جدة',
          type: 'house',
          area: 300,
          rooms: 5,
          bathrooms: 4,
          parking: true,
          furnished: false,
          price: 8000,
          status: 'available',
          owner_id: '2',
          images: ['https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&w=400'],
          amenities: ['garden', 'pool', 'garage'],
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const filteredProperties = properties.filter(property => {
    const statusMatch = filterStatus === 'all' || property.status === filterStatus;
    const typeMatch = filterType === 'all' || property.type === filterType;
    return statusMatch && typeMatch;
  });

  const handleView = (id: string) => {
    console.log('View property:', id);
  };

  const handleEdit = (id: string) => {
    console.log('Edit property:', id);
  };

  const handleDelete = (id: string) => {
    console.log('Delete property:', id);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-amber-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4 space-x-reverse">
          <button className="bg-gradient-to-r from-amber-500 to-amber-600 text-white px-6 py-3 rounded-lg flex items-center space-x-2 space-x-reverse hover:from-amber-600 hover:to-amber-700 transition-all shadow-lg">
            <Plus className="w-5 h-5" />
            <span>إضافة عقار جديد</span>
          </button>
          
          <div className="flex items-center space-x-2 space-x-reverse">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-amber-100 text-amber-700' : 'text-slate-600 hover:bg-slate-100'}`}
            >
              <Grid className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-amber-100 text-amber-700' : 'text-slate-600 hover:bg-slate-100'}`}
            >
              <List className="w-5 h-5" />
            </button>
          </div>
        </div>

        <h1 className="text-3xl font-bold text-slate-900 text-right">إدارة العقارات</h1>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex items-center space-x-6 space-x-reverse">
          <div className="flex items-center space-x-2 space-x-reverse">
            <Filter className="w-5 h-5 text-slate-500" />
            <span className="text-sm font-medium text-slate-700">الفلاتر:</span>
          </div>
          
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="border border-slate-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:border-transparent"
          >
            <option value="all">جميع الحالات</option>
            <option value="available">متاح</option>
            <option value="rented">مؤجر</option>
            <option value="maintenance">صيانة</option>
            <option value="sold">مباع</option>
          </select>

          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="border border-slate-300 rounded-lg px-4 py-2 text-sm focus:ring-2 focus:ring-amber-500 focus:border-transparent"
          >
            <option value="all">جميع الأنواع</option>
            <option value="apartment">شقة</option>
            <option value="house">فيلا</option>
            <option value="commercial">تجاري</option>
            <option value="land">أرض</option>
          </select>

          <div className="text-sm text-slate-600">
            عرض {filteredProperties.length} من أصل {properties.length} عقار
          </div>
        </div>
      </div>

      {/* Properties Grid */}
      <div className={`grid gap-6 ${viewMode === 'grid' ? 'grid-cols-1 md:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1'}`}>
        {filteredProperties.map((property) => (
          <PropertyCard
            key={property.id}
            property={property}
            onView={handleView}
            onEdit={handleEdit}
            onDelete={handleDelete}
          />
        ))}
      </div>

      {filteredProperties.length === 0 && (
        <div className="text-center py-12">
          <Building className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-slate-900 mb-2">لا توجد عقارات</h3>
          <p className="text-slate-500 mb-4">لم يتم العثور على عقارات تطابق المعايير المحددة</p>
          <button className="bg-amber-500 text-white px-6 py-2 rounded-lg hover:bg-amber-600 transition-colors">
            إضافة أول عقار
          </button>
        </div>
      )}
    </div>
  );
};

export default Properties;