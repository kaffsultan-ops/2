export interface Property {
  id: string;
  title: string;
  address: string;
  type: 'apartment' | 'house' | 'commercial' | 'land';
  area: number;
  rooms: number;
  bathrooms: number;
  floor?: number;
  parking: boolean;
  furnished: boolean;
  price: number;
  status: 'available' | 'rented' | 'maintenance' | 'sold';
  description?: string;
  owner_id: string;
  images: string[];
  amenities: string[];
  latitude?: number;
  longitude?: number;
  created_at: string;
  updated_at: string;
}

export interface Owner {
  id: string;
  name: string;
  email: string;
  phone: string;
  national_id: string;
  address: string;
  properties_count: number;
  contract_start?: string;
  contract_end?: string;
  commission_rate: number;
  created_at: string;
  updated_at: string;
}

export interface Tenant {
  id: string;
  name: string;
  email: string;
  phone: string;
  national_id: string;
  job: string;
  salary: number;
  emergency_contact: string;
  emergency_phone: string;
  property_id: string;
  contract_start: string;
  contract_end: string;
  rent_amount: number;
  deposit: number;
  created_at: string;
  updated_at: string;
}

export interface Contract {
  id: string;
  type: 'rental' | 'management';
  property_id: string;
  tenant_id?: string;
  owner_id: string;
  start_date: string;
  end_date: string;
  monthly_rent?: number;
  commission_rate?: number;
  deposit?: number;
  terms: string;
  status: 'active' | 'expired' | 'terminated';
  created_at: string;
  updated_at: string;
}

export interface Maintenance {
  id: string;
  property_id: string;
  title: string;
  description: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  cost: number;
  assigned_to?: string;
  completed_date?: string;
  images: string[];
  created_at: string;
  updated_at: string;
}

export interface Payment {
  id: string;
  tenant_id: string;
  property_id: string;
  amount: number;
  type: 'rent' | 'deposit' | 'utilities' | 'maintenance';
  due_date: string;
  paid_date?: string;
  status: 'pending' | 'paid' | 'overdue' | 'partial';
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Notification {
  id: string;
  type: 'payment_due' | 'maintenance' | 'contract_expiry' | 'general';
  title: string;
  message: string;
  recipient_type: 'tenant' | 'owner' | 'admin';
  recipient_id: string;
  read: boolean;
  sent_via_whatsapp: boolean;
  created_at: string;
}

export interface DashboardStats {
  total_properties: number;
  occupied_properties: number;
  total_revenue: number;
  pending_payments: number;
  maintenance_requests: number;
  expiring_contracts: number;
}